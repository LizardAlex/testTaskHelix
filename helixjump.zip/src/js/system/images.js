export { default as city } from '../../images/city.png';
export { default as glow } from '../../images/glow.png';

export { default as hit1 } from '../../images/1.png';
export { default as hit2 } from '../../images/4.png';
export { default as hit3 } from '../../images/6.png';
export { default as hit4 } from '../../images/8.png';
export { default as hit5 } from '../../images/9.png';

export { default as p1 } from '../../images/p1.png';
export { default as p2 } from '../../images/p2.png';
export { default as p3 } from '../../images/p3.png';
export { default as p4 } from '../../images/p4.png';
export { default as p5 } from '../../images/p5.png';
export { default as p6 } from '../../images/p6.png';

export { default as button } from '../../images/button.png';
export { default as stores } from '../../images/stores.png';
export { default as icon } from '../../images/icon.png';

export { default as barFilled } from '../../images/barFilled.png';
export { default as circleEmpty } from '../../images/circleEmpty.png';
export { default as circleFilled } from '../../images/circleFilled.png';
export { default as barEmpty } from '../../images/barEmpty.png';
export { default as circleNext } from '../../images/circleNext.png';
export { default as banner } from '../../images/banner.png';

export { default as hand } from '../../images/hand.png';
export { default as circle } from '../../images/circle.png';

export { default as ballTexture } from '../../images/ballTexture.png';
export { default as platformTexture } from '../../images/platformTexture.png';
export { default as poleTexture } from '../../images/poleTexture.png';