export { default as platform } from '../../models/platform.fbx';
export { default as platformFull } from '../../models/platformFull.fbx';
